package com.example.dell.offline1;

/**
 * Created by DELL on 01-Jun-17.
 */
public class ConstantClass {
    public static String personName="";
    public static String isLandlord="";
    public static String NIDNumber="";
    public static int HouseId=0;
    public static int Flag=0;


}
